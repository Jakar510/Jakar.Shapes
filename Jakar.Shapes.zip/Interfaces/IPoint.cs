﻿// Jakar.Extensions :: Jakar.Extensions
// 06/26/2025  16:26

namespace Jakar.Shapes.Interfaces;


public interface IPoint<TSelf> : IShape<TSelf>, IShapeLocation
    where TSelf : struct, IPoint<TSelf>, IJsonModel<TSelf>, IEqualComparable<TSelf>
{
    [Pure] public abstract static TSelf Create( double x, double y );


    public static string ToString( ref readonly TSelf self, string? format )
    {
        switch ( format )
        {
            case "json":
            case "JSON":
            case "Json":
                return self.ToJson();

            case ",":
                return $"{self.X},{self.Y}";

            case "-":
                return $"{self.X}-{self.Y}";

            case EMPTY:
            case null:
            default:
                return $"{typeof(TSelf).Name}<{nameof(X)}: {self.X}, {nameof(Y)}: {self.Y}>";
        }
    }
}
